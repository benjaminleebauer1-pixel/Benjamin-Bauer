
let Master ={
0: {
    title: "I'm_Still_Here",
    type: "Poem",
    wordCount: 80,
    WIPStatis: false,
    DateCreated: "2025-05-20"
},
 1: {
    title: "The_Shadows_Always_With_You",
    type: "Story",
    wordCount: 495,
    WIPStatis: false,
    DateCreated: "2025-05-21"
},
    2: {
    title: "Demon_Wings",
    type: "Poem",
    wordCount: 141,
    WIPStatis: false,  
    DateCreated: "2025-11-17"
    },
    3: {
    title: "The_Robot_of_Art",
    type: "Story",   
    wordCount: 449,
    WIPStatis: true,
    DateCreated: "2024-4-29"
    },
       4: {
    title: "Forgotten_Gashes",
    type: "Poem",   
    wordCount: 127,
    WIPStatis: false,
    DateCreated: "2024-9-16"
    },
    5: {
    title: "Arbitrary_Assignment",
    type: "Poem",
    wordCount: 318,
    WIPStatis: false,
    DateCreated: "2024-1-14"
},
6:{
    title: "Mother",
    type: "Poem",
    wordCount: 258,
    WIPStatis: false,
    DateCreated: "2024-6-26"
}

};






function createTable(Artsy){
    let table = document.getElementById("It's a table bro");

    while (table.rows.length > 1) table.deleteRow(1);

    for(let ID in Artsy){
        let item = Artsy[ID];
        let { title, type, wordCount, WIPStatis, DateCreated } = item;
        let TR = document.createElement("tr");
        table.appendChild(TR);

        let AddTitle = document.createElement("td");
        let LANK = document.createElement("a");
        LANK.href = title + ".html";
        LANK.textContent = title.replace(/_/g, " ");
        AddTitle.appendChild(LANK);
        TR.appendChild(AddTitle);

        let AddType = document.createElement("td");
        AddType.textContent = type;
        TR.appendChild(AddType);
        let AddWordCount = document.createElement("td");
        AddWordCount.textContent = wordCount;
        TR.appendChild(AddWordCount);


        let AddWIPStatus = document.createElement("td");
        AddWIPStatus.textContent = WIPStatis ? "WIP" : "Finished";
        TR.appendChild(AddWIPStatus);


        let AddDateCreated = document.createElement("td");
        AddDateCreated.textContent = DateCreated;
        TR.appendChild(AddDateCreated);
    }



}

function SortWordCount(){
    let WordSort = Object.values(Master);
    WordSort.sort((a, b) => a.wordCount - b.wordCount);

    createTable(WordSort);
}


function SortWIPStatus(){
    let WIPSort = Object.values(Master);
    WIPSort.sort((a, b) => a.WIPStatis - b.WIPStatis);

    createTable(WIPSort);
}

function SortType(){
    let TypeSort = Object.values(Master);
    TypeSort.sort((a, b) => a.type.localeCompare(b.type));

    createTable(TypeSort);
}

function SortDateCreated(){
    let DateSort = Object.values(Master);
    DateSort.sort((a, b) => new Date(a.DateCreated) - new Date(b.DateCreated));

    createTable(DateSort);
}

function SortAlphabetically(){
    let AlphaSort = Object.values(Master);
    AlphaSort.sort((a, b) => a.title.localeCompare(b.title));

    createTable(AlphaSort);
}

createTable(Master);

document.getElementById("The Loader").style.display = "none";


let Wbutton = document.getElementById("sortWords");
document.getElementById("sortWords").addEventListener("click", SortWordCount);

let WIPbutton = document.getElementById("sortWIP");
document.getElementById("sortWIP").addEventListener("click", SortWIPStatus);

let Typebutton = document.getElementById("sortType");
document.getElementById("sortType").addEventListener("click", SortType);

let Datebutton = document.getElementById("sortDate");
document.getElementById("sortDate").addEventListener("click", SortDateCreated);

let Alphabutton = document.getElementById("sortAlpha");
document.getElementById("sortAlpha").addEventListener("click", SortAlphabetically);
